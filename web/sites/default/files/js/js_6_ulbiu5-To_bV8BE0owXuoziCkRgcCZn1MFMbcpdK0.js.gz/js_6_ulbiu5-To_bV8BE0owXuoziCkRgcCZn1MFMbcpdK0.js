/**
 * @file
 * Lando Blog behaviors.
 */
(function (Drupal) {

  'use strict';

  Drupal.behaviors.landoBlog = {
    attach (context, settings) {

      console.log('It works!');

    }
  };

} (Drupal));
;
